#pragma once
#include <iostream>

using namespace std;

class Display {
public:
    void displayMenu();
    void displayHistogram();
};
