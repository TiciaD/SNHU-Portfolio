#pragma once
#include <iostream>

using namespace std;

class Console {
public:
    float readNumber(string prompt);
    float readNumber();
    string readString(string prompt);
};
